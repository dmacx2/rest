package com.qa.base;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Clase base de la que heredan todas las clases de test del servicio
 * "Payroll Account Pre-Registration Service" (contrato payroll.yaml).
 * Carga la configuración (base.url, etc.) desde config.properties
 * y construye una RequestSpecification reutilizable con logging y los
 * headers obligatorios/opcionales definidos en components.parameters
 * del spec (TraceId, SpanId, ChannelId, OriginatingApplicationCode,
 * CountryCode, ApiVersion).
 */
public class BaseTest {

    protected RequestSpecification requestSpec;
    protected static final Properties config = new Properties();

    @BeforeClass(alwaysRun = true)
    public void setUp() throws IOException {
        loadConfig();

        RestAssured.baseURI = config.getProperty("base.url");

        requestSpec = new RequestSpecBuilder()
                .setBaseUri(RestAssured.baseURI)
                .setContentType(ContentType.JSON)
                .addHeaders(defaultHeaders())
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();
    }

    /**
     * Headers requeridos por TODOS los endpoints del contrato payroll.yaml.
     * x-api-version es opcional en el spec pero se envía con un valor por
     * defecto. Cada test puede sobre-escribir un header puntual con
     * .header("nombre", "valor") para construir casos negativos
     * (ej. canal inválido, país no soportado, etc.).
     */
    protected Map<String, String> defaultHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("x-b3-traceid", config.getProperty("trace.id", "41200de3d3e82a81"));
        headers.put("x-b3-spanid", config.getProperty("span.id", "41200de3d3e82a81"));
        headers.put("x-channel-id", config.getProperty("channel.id", "BackOffice"));
        headers.put("x-originating-appl-code", config.getProperty("originating.appl.code", "BDMS"));
        headers.put("x-country-code", config.getProperty("country.code", "MX"));
        headers.put("x-api-version", config.getProperty("api.version", "1.1"));
        return headers;
    }

    private void loadConfig() throws IOException {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (is == null) {
                throw new IOException("No se encontró config.properties en src/test/resources");
            }
            config.load(is);
        }
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        // Espacio para limpieza posterior a la clase
    }
}
