package com.qa.tests;

import com.qa.base.BaseTest;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * Suite de pruebas para POST /payroll/confirm
 * operationId: confirmPayrollAccount
 * Contrato: payroll.yaml
 */
public class ConfirmPayrollAccountApiTest extends BaseTest {

    private static final String ENDPOINT = "/payroll/confirm";

    @Test(description = "200 - Confirmación de cuenta nómina procesada exitosamente")
    public void testConfirmPayrollAccount_Success() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", config.getProperty("test.curp", "AAAA990101MDFKLB87"));
        body.put("rfc", config.getProperty("test.rfc", "AAAA990101AB1"));
        body.put("clabe", config.getProperty("test.clabe", "002010077777777771"));

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(200)
                .body("notifications[0].code", equalTo("I200PYRLPREREG000"))
                .body("notifications[0].severity", equalTo("INFO"));
    }

    @Test(description = "400 - clabe ausente (curp, rfc y clabe son requeridos)")
    public void testConfirmPayrollAccount_BadRequest_MissingClabe() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", config.getProperty("test.curp", "AAAA990101MDFKLB87"));
        body.put("rfc", config.getProperty("test.rfc", "AAAA990101AB1"));
        // clabe ausente a propósito

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(400)
                .body("notifications[0].code", equalTo("E400PYRLPREREG001"));
    }

    @Test(description = "404 - No existe pre-registro para el CURP/RFC dados")
    public void testConfirmPayrollAccount_NotFound() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", "ZZZZ000101HDFRRR00");
        body.put("rfc", "ZZZZ000101ZZ9");
        body.put("clabe", "002010077777777771");

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(404)
                .body("notifications[0].code", equalTo("E404PYRLPREREG004"));
    }

    @Test(description = "409 - Vigencia del pre-registro expirada o registro en estado inválido")
    public void testConfirmPayrollAccount_Conflict_ExpiredPreRegistration() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", config.getProperty("test.curp.expired", "BBBB880202MDFKLB99"));
        body.put("rfc", config.getProperty("test.rfc.expired", "BBBB880202AB2"));
        body.put("clabe", "002010077777777772");

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(409)
                .body("notifications[0].code", equalTo("E409PYRLPREREG005"));
    }
}
