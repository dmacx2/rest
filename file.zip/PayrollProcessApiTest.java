package com.qa.tests;

import com.qa.base.BaseTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * Suite de pruebas para los 4 procesos batch del tag "Processes" en
 * payroll.yaml. Los 4 comparten el schema ProcessRequest
 * (job_id, execution_date, origin) y responden 202 ACCEPTED al disparar
 * la ejecución asíncrona:
 *
 *  - POST /payroll/nominees/task/candidate/pre-register          (executePreRegistrationProcess)
 *  - POST /payroll/nominees/task/corporate/send-reminder         (executeCompanyTrackingProcess)
 *  - POST /payroll/nominees/task/candidate/eligibility-reminder  (executeRemindersProcess)
 *  - POST /payroll/nominees/task/temporal-registry/maint         (executeExpirationProcess)
 */
public class PayrollProcessApiTest extends BaseTest {

    @DataProvider(name = "processEndpoints")
    public Object[][] processEndpoints() {
        return new Object[][]{
                {"/payroll/nominees/task/candidate/pre-register", "JOB-PREREG"},
                {"/payroll/nominees/task/corporate/send-reminder", "JOB-CORPREMINDER"},
                {"/payroll/nominees/task/candidate/eligibility-reminder", "JOB-ELIGREMINDER"},
                {"/payroll/nominees/task/temporal-registry/maint", "JOB-EXPMAINT"}
        };
    }

    @Test(description = "202 - Proceso batch disparado exitosamente", dataProvider = "processEndpoints")
    public void testExecuteProcess_Accepted(String endpoint, String jobPrefix) {
        Map<String, String> body = buildProcessRequest(jobPrefix);

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(endpoint)
                .then()
                .statusCode(202)
                .body("notifications[0].code", equalTo("I202PYRLPREREG000"))
                .body("notifications[0].category", equalTo("ACCEPTED"));
    }

    @Test(description = "400 - job_id, execution_date y origin ausentes", dataProvider = "processEndpoints")
    public void testExecuteProcess_BadRequest(String endpoint, String jobPrefix) {
        Map<String, String> body = new HashMap<>(); // sin campos requeridos

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(endpoint)
                .then()
                .statusCode(400)
                .body("notifications[0].code", equalTo("E400PYRLPREREG001"));
    }

    private Map<String, String> buildProcessRequest(String jobPrefix) {
        Map<String, String> body = new HashMap<>();
        body.put("job_id", jobPrefix + "-" + System.currentTimeMillis());
        body.put("execution_date", "2026-06-19T02:00:00Z");
        body.put("origin", "SCHEDULER");
        return body;
    }
}
