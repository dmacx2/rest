package com.qa.tests;

import com.qa.base.BaseTest;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Suite de pruebas para POST /payroll/pre-registration
 * operationId: getEmployeePreRegistration
 * Contrato: payroll.yaml
 */
public class PreRegistrationApiTest extends BaseTest {

    private static final String ENDPOINT = "/payroll/pre-registration";

    @Test(description = "200 - Pre-registro encontrado para CURP/RFC válidos")
    public void testGetEmployeePreRegistration_Success() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", config.getProperty("test.curp", "AAAA990101MDFKLB87"));
        body.put("rfc", config.getProperty("test.rfc", "AAAA990101AB1"));

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(200)
                .body("data.employee_name", notNullValue())
                .body("data.tdd_delivery_type", notNullValue());
    }

    @Test(description = "400 - curp y rfc ausentes (request body malformado)")
    public void testGetEmployeePreRegistration_BadRequest() {
        Map<String, String> body = new HashMap<>(); // sin curp/rfc

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(400)
                .body("notifications[0].code", equalTo("E400PYRLPREREG001"))
                .body("notifications[0].category", equalTo("BAD_REQUEST"));
    }

    @Test(description = "404 - No existe pre-registro para el CURP/RFC dados")
    public void testGetEmployeePreRegistration_NotFound() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", "ZZZZ000101HDFRRR00");
        body.put("rfc", "ZZZZ000101ZZ9");

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(404)
                .body("notifications[0].code", equalTo("E404PYRLPREREG004"))
                .body("notifications[0].category", equalTo("NOT_FOUND"));
    }

    @Test(description = "401 - Credenciales inválidas (header de canal/país requerido alterado)")
    public void testGetEmployeePreRegistration_Unauthorized() {
        Map<String, String> body = new HashMap<>();
        body.put("curp", config.getProperty("test.curp", "AAAA990101MDFKLB87"));
        body.put("rfc", config.getProperty("test.rfc", "AAAA990101AB1"));

        given()
                .spec(requestSpec)
                .header("x-originating-appl-code", "INVALID_APP")
                .body(body)
                .when()
                .post(ENDPOINT)
                .then()
                .statusCode(401)
                .body("notifications[0].code", equalTo("E401PYRLPREREG002"));
    }
}
